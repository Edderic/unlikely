import numpy as np

def add_one(number):
    return number + 1

def random_sample():
    return np.random.beta(1,1, 1000)


